public class Dishdecorator implements Dish {

    protected Dish decoratedDish;

    public Dishdecorator(Dish decoratedDish) {
        this.decoratedDish = decoratedDish;
    }

    @Override
    public void cook() {
        decoratedDish.cook();

    }

}

class addToppings extends Dishdecorator {

    public addToppings(Dish decoratedDish) {
        super(decoratedDish);

    }

    public void cook() {
        decoratedDish.cook();
        toppingsAdded(decoratedDish);

    }

    private void toppingsAdded(Dish decoratedDish) {

        System.out.println("Toppings added to " + decoratedDish);
    }

}

class addSpices extends Dishdecorator {

    public addSpices(Dish decoratedDish) {
        super(decoratedDish);

    }

    public void cook() {
        decoratedDish.cook();
        spicesAdded(decoratedDish);

    }

    private void spicesAdded(Dish decoratedDish) {

        System.out.println("Spices added to " + decoratedDish);
    }

}

class addGarnishing extends Dishdecorator {

    public addGarnishing(Dish decoratedDish) {
        super(decoratedDish);

    }

    public void cook() {
        decoratedDish.cook();
        garnishingAdded(decoratedDish);

    }

    private void garnishingAdded(Dish decoratedDish) {

        System.out.println("Garnishing done for " + decoratedDish);
    }

}

class addSideD extends Dishdecorator {

    public addSideD(Dish decoratedDish) {
        super(decoratedDish);

    }

    public void cook() {
        decoratedDish.cook();
        sidedadded(decoratedDish);

    }

    private void sidedadded(Dish decoratedDish) {

        System.out.println("Side dish added to " + decoratedDish);
    }

}
