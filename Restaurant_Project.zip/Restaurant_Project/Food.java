class Pizza implements Dish {

    @Override
    public void cook() {
        System.out.println("Pizza being cooked");

    }

}

class Milkshake implements Dish {

    @Override
    public void cook() {
        System.out.println("Milkshake being prepared");

    }

}

class Pasta implements Dish {

    @Override
    public void cook() {
        System.out.println("Pasta being cooked");

    }

}

class Dosa implements Dish {

    @Override
    public void cook() {
        System.out.println("Dosa being prepared");

    }

}

class PaniPuri implements Dish {

    @Override
    public void cook() {
        System.out.println("Panipuri being prepared");

    }

}
