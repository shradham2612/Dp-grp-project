public interface Dish {
    public void cook();
}
