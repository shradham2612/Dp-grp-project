import java.util.*;
import java.util.Scanner;

abstract class OrderTemplate {

	public abstract void Order();

	public abstract void Cooking();

	public abstract void Serving();

	public abstract void Payment();

	public void StartProcess() {
		Order();
		Cooking();
		Serving();
		Payment();
	}
}

class Netorder extends OrderTemplate {

	@Override
	public void Order() {
		System.out.println("\tWelcome To Our Restaurant\n\tEnter Number to place your order");
		// Printing of arraylist menucard
		// Calling abstract factory method

		ArrayList<String> menu = new ArrayList<String>();
		menu.add("1--Pizza");
		menu.add("2--Milkshake");
		menu.add("3--Pasta");
		menu.add("4--Dosa");
		menu.add("5--Panipuri");

		for (String i : menu) {
			System.out.println(i);
		}

		Scanner myObj = new Scanner(System.in);
		System.out.println("Enter one of the above option : ");
		// int option = myObj.nextInt();

		int option = myObj.nextInt();
		// String s = myObj.nextLine();

		// Break
		System.out.println("Option selected is : " + option);
		AbstractFoodFactory Myfood = new FoodFactory();
		System.out.println("Step 1");
		Dish d = Myfood.GetDish(option);
		System.out.println("Step 2");

		d.cook();
		System.out.println("Step 3");

	}

	@Override
	public void Cooking() {
		System.out.println("\n\tYour Food is Cooking\n");
	}

	@Override
	public void Serving() {
		// Implementation of Decorator

	}

	@Override
	public void Payment() {
		System.out.println("\n\tYour Payment is Processing.....\n\tPayment Successfull !");

	}

}